#Random generator ipv6 addresses within your ipv6 network prefix.
#!/usr/local/bin/bash

# Copyright
# Vladislav V. Prodan
# universite@ukr.net
# 2011


array=( 1 2 3 4 5 6 7 8 9 0 a b c d e f )
MAXCOUNT=4000
count=1
network=2a0a:4781:0::/36 # your ipv6 network prefix
len=4

rnd_ip_block ()
{
    b=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
    c=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
    d=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
    e=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
    f=${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}${array[$RANDOM%16]}
    echo $sub_network:$b:$c:$d:$e:$f
}

#echo "$MAXCOUNT случайных IPv6:"
#echo "-----------------"
while [ "$count" -le $MAXCOUNT ]        # Генерация 20 ($MAXCOUNT) случайных чисел.
do
        a=`echo 'ibase=10;obase=16;'$count | bc | tr '[:upper:]' '[:lower:]'`
        if [ ${#a} -lt $len ]
        then
        t=$[$len-${#a}]
        i=1
        while [ $i -lt $t ]; do
        a="0"$a
        let "i += 1"
        done
        fi
        sub_network=$network$a
        rnd_ip_block
        let "count += 1"                # Нарастить счетчик.
        done
#echo "-----------------"

