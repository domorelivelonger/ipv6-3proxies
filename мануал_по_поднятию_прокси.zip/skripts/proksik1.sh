#!/bin/bash
# Copyright
# Boris O. Baktashev
# http://kak-podnyat-proksi-ipv6.ru
# 2016


ipv4=185.118.66.108
portproxy=30000
user=proksik
pass=45Dg4K48
config="/root/3proxy/3proxy.cfg"


echo "daemon" >> $config
echo "maxconn 1000" >> $config
echo "nscache 65536" >> $config
echo "timeouts 1 5 30 60 180 1800 15 60" >> $config
echo "setgid 65535" >> $config
echo "setuid 65535" >> $config
echo "flush" >> $config
echo "auth strong" >> $config
echo  "users $user:CL:$pass" >> $config
echo "allow $user" >> $config

for i in `cat ip.list`; do
    echo "proxy -n -a -6 -p$portproxy -i$ipv4 -e$i" >> $config
    ((inc+=1))
    ((portproxy+=1))
	echo "$ipv4:$portproxy:$user:$pass" >> proxylist.txt
done
